package com.manara.portail.service;

import com.manara.portail.model.ActiviteAdmin;
import com.manara.portail.model.Inscription;
import com.manara.portail.model.InscriptionEnfant;
import com.manara.portail.repository.ActiviteRepository;
import com.manara.portail.repository.InscriptionEnfantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ActiviteService {
    @Autowired
    private ActiviteRepository activiteRepository;
    @Autowired
    private InscriptionEnfantRepository inscriptionRepository;

    public List<ActiviteAdmin> getAllActivites() {
        return activiteRepository.findAll();
    }

    public ActiviteAdmin save(ActiviteAdmin activite) {
        return activiteRepository.save(activite);
    }

    public ActiviteAdmin getById(Long id) {
        return activiteRepository.findById(id).orElse(null);
    }

    public void deleteById(Long id) {
        ActiviteAdmin activite = getById(id);
        if (activite == null) {
            throw new RuntimeException("Activité introuvable");
        }
        activiteRepository.delete(activite);
    }

    public int getPourcentageInscription() {
        List<ActiviteAdmin> activites = activiteRepository.findAll();
        if (activites.isEmpty()) return 0;
        long totalInscrits = activites.stream().mapToLong(ActiviteAdmin::getNbInscrits).sum();
        long totalCapacite = activites.stream().mapToInt(ActiviteAdmin::getCapacite).sum();
        if (totalCapacite == 0) return 0;
        return (int) ((totalInscrits * 100) / totalCapacite);
    }

    public boolean isComplet(ActiviteAdmin activite) {
        return activite.isComplet();
    }

    public List<ActiviteAdmin> getActivites() {
        return activiteRepository.findAll();
    }
}
